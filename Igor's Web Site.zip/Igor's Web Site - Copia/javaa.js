



 
function escolherBanda(){
	var banda = document.getElementById("bandlist").value;
	
switch(banda){
	case "Avanged Sevenfold":
	document.getElementById("band-name").innerHTML="Avanged Sevenfold";
	document.getElementById("song-name").innerHTML="Hail to the King";
	document.getElementById("band-logo").src="images/Avenged-Sevenfold-PNG.png";
	document.getElementById("audio").src="images/Avanged Sevenfold-Hail to the king.mp3";	
	break;
	
	case "Five Finger Death Punch":
	document.getElementById("band-name").innerHTML="Five Finger Death Punch";
	document.getElementById("song-name").innerHTML="My nemesis";
	document.getElementById("band-logo").src="images/five_finger_death_punch_iconpng.png";
	document.getElementById("audio").src="images/Five Finger Death P-My nemesis.mp3";
	
	
	break;
	
	case "Skillet":
	document.getElementById("band-name").innerHTML="Skillet";
	document.getElementById("song-name").innerHTML="Feel invincible";
	document.getElementById("band-logo").src="images/Skillet img.png";
	document.getElementById("audio").src="images/Skillet-Feel-Invincible.mp3";
	
	break;
	
	case "Slipknot":
	document.getElementById("band-name").innerHTML="Slipknot";
	document.getElementById("song-name").innerHTML="Dead memories";
	document.getElementById("band-logo").src="images/Slipknot.png";
	document.getElementById("audio").src="images/Slipknot-Dead Memories.mp3";
	
	break;
	
	case "Creed":
	document.getElementById("band-name").innerHTML="Creed";
	document.getElementById("song-name").innerHTML="My own prison";
	document.getElementById("band-logo").src="images/creed.png";
	document.getElementById("audio").src="images/Creed -My Own Prison original.mp3";
	break;
	}
	

}




function ffdpFunction(){
	document.getElementById("band-name").innerHTML="Five Finger Death Punch";
	document.getElementById("song-name").innerHTML="My nemesis";
	document.getElementById("band-logo").src="images/five_finger_death_punch_iconpng.png";
	document.getElementById("audio").src="images/Five Finger Death P-My nemesis.mp3";
	}
	
function as(){ 
	document.getElementById("band-name").innerHTML="Avanged Sevenfold";
	document.getElementById("song-name").innerHTML="Hail to the King";
	document.getElementById("band-logo").src="images/Avenged-Sevenfold-PNG.png";
	document.getElementById("audio").src="images/Avanged Sevenfold-Hail to the king.mp3";	}
	
	
function skillet(){
	document.getElementById("band-name").innerHTML="Skillet";
	document.getElementById("song-name").innerHTML="Feel invincible";
	document.getElementById("band-logo").src="images/Skillet img.png";
	document.getElementById("audio").src="images/Skillet-Feel-Invincible.mp3";}
function slipknot(){
	document.getElementById("band-name").innerHTML="Slipknot";
	document.getElementById("song-name").innerHTML="Dead memories";
	document.getElementById("band-logo").src="images/Slipknot.png";
	document.getElementById("audio").src="images/Slipknot-Dead Memories.mp3";}
	
function creed(){
	document.getElementById("band-name").innerHTML="Creed";
	document.getElementById("song-name").innerHTML="My own prison";
	document.getElementById("band-logo").src="images/creed.png";
	document.getElementById("audio").src="images/Creed -My Own Prison original.mp3";}